#ifndef __ACCELEROMETER_CALIBRATION_H
#define __ACCELEROMETER_CALIBRATION_H

void accel_mat_init(void);
void cali_fenction(void);
void caculate_mat(float *ax,float *ay,float *az);
#endif
