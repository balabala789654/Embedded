#ifndef __MPU_DELAY_H__
#define __MPU_DELAY_H__

void mpu_delay_ms(unsigned int t);
void mpu_delay_us(unsigned int t);

#endif 
